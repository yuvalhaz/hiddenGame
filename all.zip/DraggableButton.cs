using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;

/// <summary>
/// Main draggable button component. Handles drag events and coordinates
/// with helper classes for visuals, validation, and animations.
/// </summary>
[RequireComponent(typeof(RectTransform))]
[RequireComponent(typeof(CanvasGroup))]
public class DraggableButton : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [Header("Settings")]
    [SerializeField] private float dragThreshold = 50f;
    [SerializeField] private float dropDistanceThreshold = 150f;
    [SerializeField] private Canvas topCanvas;

    [Header("Animation")]
    [SerializeField] private bool animateSizeChange = true;
    [SerializeField] private float sizeAnimationDuration = 0.5f;

    [Header("Success Effects")]
    [SerializeField] private bool showConfettiOnSuccess = true;
    [SerializeField] private int confettiCount = 50;

    [Header("Debug")]
    [SerializeField] private bool debugMode = false;

    // Components
    private ScrollableButtonBar buttonBar;
    private RectTransform rectTransform;
    private CanvasGroup canvasGroup;
    private ScrollRect parentScrollRect;

    // State
    private string buttonID;
    private int originalIndex;
    private Vector2 originalPosition;
    private bool isDragging = false;
    private bool isDraggingOut = false;
    private bool wasSuccessfullyPlaced = false;

    // Helper classes
    private DragVisualManager visualManager;
    private DragDropValidator dropValidator;

    void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>();

        if (canvasGroup == null)
        {
            canvasGroup = gameObject.AddComponent<CanvasGroup>();
        }

        parentScrollRect = GetComponentInParent<ScrollRect>();
    }

    void Start()
    {
        // Initialize helper classes
        visualManager = new DragVisualManager(buttonID, topCanvas, sizeAnimationDuration, debugMode);

        Canvas canvas = topCanvas != null ? topCanvas : GetComponentInParent<Canvas>();
        dropValidator = new DragDropValidator(canvas, dropDistanceThreshold, debugMode);
    }

    void OnDestroy()
    {
        visualManager?.Destroy();
    }

    #region Public API

    public void SetButtonBar(ScrollableButtonBar bar, int index)
    {
        buttonBar = bar;
        originalIndex = index;
    }

    public void SetButtonID(string id)
    {
        buttonID = id;
    }

    public string GetButtonID()
    {
        return buttonID;
    }

    public bool IsDragging()
    {
        return isDragging;
    }

    public void ReturnToPosition(Vector2 position)
    {
        rectTransform.anchoredPosition = position;
    }

    /// <summary>
    /// Check if this button has been successfully placed on a DropSpot.
    /// </summary>
    public bool HasBeenPlaced()
    {
        if (GameProgressManager.Instance == null)
            return false;

        return GameProgressManager.Instance.IsItemPlaced(buttonID);
    }

    #endregion

    #region Drag Event Handlers

    public void OnBeginDrag(PointerEventData eventData)
    {
        originalPosition = rectTransform.anchoredPosition;
        isDragging = true;

        canvasGroup.interactable = true;
        canvasGroup.blocksRaycasts = false;

        // Disable ScrollRect to prevent interference
        if (parentScrollRect != null)
        {
            parentScrollRect.enabled = false;
        }

        buttonBar?.OnButtonDragStarted(this, originalIndex);

        // Enable raycast on matching DropSpot
        DragDropValidator.SetDropSpotRaycastEnabled(buttonID, true);
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!isDragging) return;

        Vector2 localPoint;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            rectTransform.parent as RectTransform,
            eventData.position,
            eventData.pressEventCamera,
            out localPoint
        );

        float distanceFromOriginal = Vector2.Distance(localPoint, originalPosition);
        bool wasOut = isDraggingOut;
        isDraggingOut = distanceFromOriginal > dragThreshold;

        // Create drag visual when threshold is crossed
        if (!wasOut && isDraggingOut)
        {
            #if UNITY_EDITOR
            if (debugMode)
                Debug.Log($"[DraggableButton] Threshold crossed for {buttonID}");
            #endif

            buttonBar?.OnButtonDraggedOut(this, originalIndex);

            visualManager.Create(rectTransform, this);
            canvasGroup.alpha = 0f;

            // Return original button to its position
            rectTransform.anchoredPosition = originalPosition;
        }

        // Update drag visual position
        if (isDraggingOut && visualManager.IsActive)
        {
            visualManager.UpdatePosition(eventData);
        }
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        isDragging = false;

        // Re-enable ScrollRect
        if (parentScrollRect != null)
        {
            parentScrollRect.enabled = true;
        }

        canvasGroup.interactable = true;
        canvasGroup.blocksRaycasts = true;

        if (visualManager.IsActive)
        {
            // Validate drop
            string failureReason;
            DropSpot hitSpot = dropValidator.ValidateDrop(
                buttonID,
                visualManager.DragVisual,
                eventData,
                out failureReason
            );

            if (hitSpot != null)
            {
                // SUCCESS!
                #if UNITY_EDITOR
                if (debugMode)
                    Debug.Log($"[DraggableButton] ✅ Successful placement: {buttonID}");
                #endif

                wasSuccessfullyPlaced = true;
                canvasGroup.alpha = 1f;
                HandleSuccessfulPlacement(hitSpot);
            }
            else
            {
                // FAILURE - return to bar
                #if UNITY_EDITOR
                if (debugMode)
                    Debug.Log($"[DraggableButton] ❌ Invalid drop: {failureReason}");
                #endif

                StartCoroutine(AnimateReturnToBar());
            }
        }
        else
        {
            // No drag visual - just restore
            canvasGroup.alpha = 1f;
            canvasGroup.interactable = true;
        }

        // Disable raycast on DropSpot
        DragDropValidator.SetDropSpotRaycastEnabled(buttonID, false);

        // Notify button bar
        if (!wasSuccessfullyPlaced)
        {
            buttonBar?.OnButtonReturned(this, originalIndex);
        }

        isDraggingOut = false;
    }

    #endregion

    #region Success Handling

    private void HandleSuccessfulPlacement(DropSpot hitSpot)
    {
        // Get sprite for saving
        var revealController = hitSpot.GetComponent<ImageRevealController>();
        Sprite itemSprite = null;

        if (revealController != null)
        {
            var bgImage = revealController.GetBackgroundImage();
            if (bgImage != null && bgImage.sprite != null)
            {
                itemSprite = bgImage.sprite;
            }
        }

        // SAVE IMMEDIATELY
        if (GameProgressManager.Instance != null)
        {
            GameProgressManager.Instance.MarkItemAsPlaced(buttonID, itemSprite);
            GameProgressManager.Instance.ForceSave();

            #if UNITY_EDITOR
            if (debugMode)
                Debug.Log($"[DraggableButton] ✅ Saved: {buttonID}");
            #endif
        }
        else
        {
            Debug.LogError("[DraggableButton] GameProgressManager is NULL!");
        }

        // Settle the item on the spot
        hitSpot.SettleItem(visualManager.DragVisual);

        // Show confetti
        if (showConfettiOnSuccess && topCanvas && visualManager.IsActive)
        {
            StartCoroutine(ShowConfetti(visualManager.DragVisual));
        }

        // Cleanup
        visualManager.Destroy();

        // Notify button bar
        buttonBar?.OnButtonSuccessfullyPlaced(this, originalIndex);

        // Destroy this button after delay
        StartCoroutine(DestroyButtonAfterDelay());
    }

    private IEnumerator ShowConfetti(RectTransform target)
    {
        if (target == null || topCanvas == null) yield break;

        UIConfetti.Burst(topCanvas, target, confettiCount, 1.2f);

        yield return new WaitForSeconds(0.1f);
    }

    private IEnumerator DestroyButtonAfterDelay()
    {
        yield return new WaitForSeconds(0.2f);

        if (gameObject != null)
        {
            #if UNITY_EDITOR
            if (debugMode)
                Debug.Log($"[DraggableButton] Destroying button: {buttonID}");
            #endif

            Destroy(gameObject);
        }
    }

    #endregion

    #region Return Animation

    private IEnumerator AnimateReturnToBar()
    {
        if (!visualManager.IsActive)
        {
            canvasGroup.alpha = 1f;
            yield break;
        }

        yield return StartCoroutine(
            DragAnimator.AnimateReturnToBar(
                visualManager.DragVisual,
                rectTransform,
                onComplete: () =>
                {
                    visualManager.Destroy();
                    canvasGroup.alpha = 1f;
                }
            )
        );
    }

    #endregion
}
